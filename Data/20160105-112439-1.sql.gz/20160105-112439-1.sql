-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : hg
-- 
-- Part : #1
-- Date : 2016-01-05 11:24:40
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `hg_bill`
-- -----------------------------
DROP TABLE IF EXISTS `hg_bill`;
CREATE TABLE `hg_bill` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL COMMENT '0-包干，多次使用\r\n1-会议\r\n2-培训\r\n3-专项\r\n4-包干，一次一申请\r\n5-采购\r\n',
  `projectid` int(10) NOT NULL COMMENT '各种类型对应的预算项目id\r\n\r\n包干科目id\r\n单个会议id\r\n专项项目id等\r\n\r\n合同id\r\n\r\n一次性包干存其预算id\r\n',
  `contractmoneyid` int(10) NOT NULL COMMENT '表 Contractmoney id',
  `contractmoneyqishuid` int(2) NOT NULL COMMENT 'contractmoney中分期期数',
  `orderid` varchar(20) NOT NULL,
  `instaid` int(10) NOT NULL COMMENT '录入人员id',
  `sectionid` int(10) NOT NULL,
  `staffid` int(10) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `remark` text NOT NULL,
  `timestamp` char(10) NOT NULL,
  `termid` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '是否报销\r\n0：未报销\r\n1：已报销\r\n2：审核拒绝',
  `chestaid` int(10) NOT NULL COMMENT '审核人id',
  `unitid` int(10) NOT NULL,
  `confirm` decimal(10,2) NOT NULL COMMENT '核批金额',
  `cremark` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `billID` (`id`) USING BTREE,
  KEY `projectID` (`projectid`) USING BTREE,
  KEY `sectionID` (`sectionid`) USING BTREE,
  KEY `staffID` (`staffid`) USING BTREE,
  KEY `termID` (`termid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=186 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_bill`
-- -----------------------------
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_bill` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_bill_cailv`
-- -----------------------------
DROP TABLE IF EXISTS `hg_bill_cailv`;
CREATE TABLE `hg_bill_cailv` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `billid` int(10) NOT NULL,
  `place` varchar(50) NOT NULL,
  `day` tinyint(2) NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '1：会议\r\n2：培训\r\n3：其它',
  `people` varchar(255) NOT NULL COMMENT '出差人员',
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_bill_cailv`
-- -----------------------------
INSERT INTO `hg_bill_cailv` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_catbudget`
-- -----------------------------
DROP TABLE IF EXISTS `hg_catbudget`;
CREATE TABLE `hg_catbudget` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `termid` int(10) NOT NULL,
  `unitid` int(10) NOT NULL,
  `sectionid` int(10) NOT NULL,
  `staffid` int(10) NOT NULL,
  `categoryid` int(10) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `timestamp` char(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catbudgetID` (`id`) USING BTREE,
  KEY `termID` (`termid`) USING BTREE,
  KEY `unitID` (`unitid`) USING BTREE,
  KEY `sectionID` (`sectionid`) USING BTREE,
  KEY `staffID` (`staffid`) USING BTREE,
  KEY `catgroyID` (`categoryid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_catbudget`
-- -----------------------------
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_catbudget` VALUES ('', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_category`
-- -----------------------------
DROP TABLE IF EXISTS `hg_category`;
CREATE TABLE `hg_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL,
  `name` varchar(60) NOT NULL,
  `once` tinyint(1) NOT NULL COMMENT '1：多次使用\r\n0：一次使用',
  `level` tinyint(2) NOT NULL,
  `timestamp` char(10) NOT NULL,
  `bx_ord` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `catgroryid` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_category`
-- -----------------------------
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');
INSERT INTO `hg_category` VALUES ('', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_catlog`
-- -----------------------------
DROP TABLE IF EXISTS `hg_catlog`;
CREATE TABLE `hg_catlog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `termid` int(10) NOT NULL,
  `unitid` int(10) NOT NULL,
  `sectionid` int(10) NOT NULL,
  `staffid` int(10) NOT NULL,
  `categoryid` int(10) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `timestamp` char(10) NOT NULL,
  `billid` int(10) NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '0-初始化预算\r\n1-后台修改，增加\r\n2-后台修改，减少\r\n3-预算申请，添加\r\n4-报销',
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_catlog`
-- -----------------------------
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_catlog` VALUES ('', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_conference`
-- -----------------------------
DROP TABLE IF EXISTS `hg_conference`;
CREATE TABLE `hg_conference` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `termid` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `number` int(10) NOT NULL,
  `month` tinyint(2) NOT NULL,
  `duration` float(3,1) NOT NULL,
  `average` decimal(10,2) NOT NULL,
  `basemoney` decimal(10,2) NOT NULL,
  `sectionid` int(10) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `unitid` int(10) NOT NULL,
  `timestamp` char(10) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `confirm` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hg_contract`
-- -----------------------------
DROP TABLE IF EXISTS `hg_contract`;
CREATE TABLE `hg_contract` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `specialid` int(10) NOT NULL COMMENT '一次申请：存special_other表id\r\n多次：存spebudget表的id',
  `isother` tinyint(1) NOT NULL COMMENT '是否为一次一申请的\r\n0-多次申请，来自表special\r\n1-一次一申请，来自表specia_other',
  `name` varchar(60) NOT NULL,
  `procurement` tinyint(1) NOT NULL,
  `sectionid` int(10) NOT NULL,
  `staffid` int(10) NOT NULL,
  `project` tinyint(1) NOT NULL,
  `goods` tinyint(1) NOT NULL,
  `service` tinyint(1) NOT NULL,
  `projectmoney` decimal(10,2) NOT NULL,
  `projectremark` text NOT NULL,
  `goodsmoney` decimal(10,2) NOT NULL,
  `goodsremark` text NOT NULL,
  `servicemoney` decimal(10,2) NOT NULL,
  `serviceremark` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `timestamp` char(10) NOT NULL,
  `isover` tinyint(1) NOT NULL COMMENT '是否报销完结',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_contract`
-- -----------------------------
INSERT INTO `hg_contract` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_contract_money`
-- -----------------------------
DROP TABLE IF EXISTS `hg_contract_money`;
CREATE TABLE `hg_contract_money` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contractid` int(10) NOT NULL,
  `name` varchar(60) NOT NULL,
  `first` decimal(10,2) NOT NULL,
  `second` decimal(10,2) NOT NULL,
  `third` decimal(10,2) NOT NULL,
  `fourth` decimal(10,2) NOT NULL,
  `fifth` decimal(10,2) NOT NULL,
  `warranty` decimal(10,2) NOT NULL,
  `type` tinyint(1) NOT NULL,
  `firststatus` tinyint(1) NOT NULL,
  `secondstatus` tinyint(1) NOT NULL,
  `thirdstatus` tinyint(1) NOT NULL,
  `fourthstatus` tinyint(1) NOT NULL,
  `fifthstatus` tinyint(1) NOT NULL,
  `warrantystatus` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_contract_money`
-- -----------------------------
INSERT INTO `hg_contract_money` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_contract_money` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_contract_money` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_contract_money` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_contract_money` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_contract_money` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_income`
-- -----------------------------
DROP TABLE IF EXISTS `hg_income`;
CREATE TABLE `hg_income` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `orderid` varchar(20) NOT NULL,
  `termid` int(10) NOT NULL,
  `sectionid` int(10) NOT NULL,
  `staffid` int(10) NOT NULL,
  `categoryid` int(10) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `remark` text NOT NULL,
  `timestamp` char(10) NOT NULL,
  `once` tinyint(1) NOT NULL COMMENT '0：一次一申请\r\n1：多次申请',
  `name` varchar(60) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0：未审核\r\n1：审核通过\r\n2：审核拒绝',
  `confirm` decimal(10,2) NOT NULL,
  `cremark` text NOT NULL,
  `unitid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hg_oncebudget`
-- -----------------------------
DROP TABLE IF EXISTS `hg_oncebudget`;
CREATE TABLE `hg_oncebudget` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `termid` int(10) NOT NULL,
  `unitid` int(10) NOT NULL,
  `sectionid` int(10) NOT NULL,
  `staffid` int(10) NOT NULL,
  `categoryid` int(10) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `timestamp` char(10) NOT NULL,
  `name` varchar(60) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0：未申请报销\r\n1：申请报销未审核\r\n2：申请报销并审核通过',
  `confirm` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hg_placard`
-- -----------------------------
DROP TABLE IF EXISTS `hg_placard`;
CREATE TABLE `hg_placard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `highlight` tinyint(1) NOT NULL,
  `bold` tinyint(1) NOT NULL,
  `content` text NOT NULL,
  `timestamp` char(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_placard`
-- -----------------------------
INSERT INTO `hg_placard` VALUES ('', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_role`
-- -----------------------------
DROP TABLE IF EXISTS `hg_role`;
CREATE TABLE `hg_role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `rules` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_role`
-- -----------------------------
INSERT INTO `hg_role` VALUES ('', '', '');
INSERT INTO `hg_role` VALUES ('', '', '');
INSERT INTO `hg_role` VALUES ('', '', '');
INSERT INTO `hg_role` VALUES ('', '', '');
INSERT INTO `hg_role` VALUES ('', '', '');
INSERT INTO `hg_role` VALUES ('', '', '');

-- -----------------------------
-- Table structure for `hg_rule`
-- -----------------------------
DROP TABLE IF EXISTS `hg_rule`;
CREATE TABLE `hg_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `condition` char(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_rule`
-- -----------------------------
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_rule` VALUES ('', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_section`
-- -----------------------------
DROP TABLE IF EXISTS `hg_section`;
CREATE TABLE `hg_section` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `unitid` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `timestamp` char(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_section`
-- -----------------------------
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');
INSERT INTO `hg_section` VALUES ('', '', '', '');

-- -----------------------------
-- Table structure for `hg_spebudget`
-- -----------------------------
DROP TABLE IF EXISTS `hg_spebudget`;
CREATE TABLE `hg_spebudget` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `specialid` int(10) NOT NULL,
  `firstallmoney` decimal(10,2) NOT NULL COMMENT '总量',
  `money` decimal(10,2) NOT NULL COMMENT '除去报销，剩余',
  `sectionid` int(10) NOT NULL,
  `unitid` int(10) NOT NULL,
  `timestamp` char(10) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `spebudgetid` (`id`) USING BTREE,
  KEY `sectionID` (`sectionid`) USING BTREE,
  KEY `unitID` (`unitid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_spebudget`
-- -----------------------------
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_spebudget` VALUES ('', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_special`
-- -----------------------------
DROP TABLE IF EXISTS `hg_special`;
CREATE TABLE `hg_special` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL,
  `unitid` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gov` tinyint(1) NOT NULL COMMENT '0：非政府预算\r\n1：政府预算',
  `year` smallint(4) NOT NULL,
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `bx_ord` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `specialid` (`id`) USING BTREE,
  KEY `specialpid` (`pid`) USING BTREE,
  KEY `unitID` (`unitid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_special`
-- -----------------------------
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_special` VALUES ('', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_special_other`
-- -----------------------------
DROP TABLE IF EXISTS `hg_special_other`;
CREATE TABLE `hg_special_other` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `year` char(4) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `sectionid` int(10) NOT NULL,
  `unitid` int(10) NOT NULL,
  `staffid` int(10) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `timestamp` char(10) NOT NULL,
  `confirm` tinyint(1) NOT NULL,
  `confirmmoney` decimal(10,2) NOT NULL,
  `cremark` varchar(100) DEFAULT NULL,
  `used` tinyint(1) NOT NULL COMMENT '0-没有用\r\n1-已经用',
  `usedmoney` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hg_spelog`
-- -----------------------------
DROP TABLE IF EXISTS `hg_spelog`;
CREATE TABLE `hg_spelog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `unitid` int(10) NOT NULL,
  `sectionid` int(10) NOT NULL,
  `staffid` int(10) NOT NULL,
  `spebudid` int(10) NOT NULL COMMENT '存 hg_spebudget id\r\n',
  `billid` int(10) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '1：普通报销\r\n2：采购合同报销',
  `logdate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;

-- -----------------------------
-- Records of `hg_spelog`
-- -----------------------------
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_spelog` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_staff`
-- -----------------------------
DROP TABLE IF EXISTS `hg_staff`;
CREATE TABLE `hg_staff` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `number` char(7) NOT NULL,
  `sectionid` int(10) unsigned NOT NULL,
  `password` char(32) NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  `roleid` int(10) NOT NULL,
  `timestamp` char(10) NOT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `stafffid` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=641 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_staff`
-- -----------------------------
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');
INSERT INTO `hg_staff` VALUES ('', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_term`
-- -----------------------------
DROP TABLE IF EXISTS `hg_term`;
CREATE TABLE `hg_term` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `staffid` int(10) unsigned NOT NULL,
  `timestamp` char(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_term`
-- -----------------------------
INSERT INTO `hg_term` VALUES ('', '', '', '', '');
INSERT INTO `hg_term` VALUES ('', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_train`
-- -----------------------------
DROP TABLE IF EXISTS `hg_train`;
CREATE TABLE `hg_train` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `termid` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `remark` text NOT NULL,
  `total` tinyint(3) NOT NULL,
  `staging` tinyint(3) NOT NULL COMMENT '期数，培训报销以此期数报销',
  `number` int(10) NOT NULL,
  `place` varchar(255) NOT NULL,
  `duration` float(3,1) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `origin` varchar(255) NOT NULL,
  `sectionid` int(10) NOT NULL,
  `unitid` int(10) NOT NULL,
  `timestamp` char(10) NOT NULL,
  `confirm` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hg_unit`
-- -----------------------------
DROP TABLE IF EXISTS `hg_unit`;
CREATE TABLE `hg_unit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `timestamp` char(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_unit`
-- -----------------------------
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');
INSERT INTO `hg_unit` VALUES ('', '', '');

-- -----------------------------
-- Table structure for `hg_wagesgq`
-- -----------------------------
DROP TABLE IF EXISTS `hg_wagesgq`;
CREATE TABLE `hg_wagesgq` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `num` int(10) NOT NULL COMMENT '序号',
  `section` varchar(8) NOT NULL COMMENT '部门名称',
  `name` varchar(16) NOT NULL COMMENT '用户姓名',
  `card` varchar(20) NOT NULL COMMENT '卡号',
  `level_wages` decimal(8,2) NOT NULL COMMENT '级别工资',
  `job_wages` decimal(8,2) NOT NULL COMMENT '职务工资',
  `proportion_subsidies` decimal(8,2) NOT NULL COMMENT '按比例计算的津贴',
  `gaoxin_subsidies` decimal(8,2) NOT NULL COMMENT '高新补贴',
  `port_subsidies` decimal(8,2) NOT NULL COMMENT '口岸补贴',
  `keep_subsidies` decimal(8,2) NOT NULL COMMENT '保留津贴',
  `appropriate_subsidies` decimal(8,2) NOT NULL COMMENT '适当补贴',
  `job_subsidies` decimal(8,2) NOT NULL COMMENT '职务补贴',
  `haiguan_subsidies` decimal(8,2) NOT NULL COMMENT '海关津贴',
  `onechild` decimal(8,2) NOT NULL COMMENT '独生子女费',
  `phone_subsidies` decimal(8,2) NOT NULL COMMENT '移动电话费',
  `giveadd` decimal(8,2) NOT NULL COMMENT '应发合计',
  `de_gongjijing` decimal(8,2) NOT NULL COMMENT '所得税扣除公积金',
  `de_medicalinsurance` decimal(8,2) NOT NULL COMMENT '所得税扣除医疗保险',
  `de_unemploy` decimal(8,2) NOT NULL COMMENT '所得税扣除失业保险',
  `de_onechild` decimal(8,2) NOT NULL COMMENT '所得税扣除独生子女',
  `de_phone` decimal(8,2) NOT NULL COMMENT '所得税扣除移动电话及座机',
  `de_other` decimal(8,2) NOT NULL COMMENT '所得税扣除其他扣款',
  `de_taxadd` decimal(8,2) NOT NULL COMMENT '应缴税所得额',
  `individualtax` decimal(8,2) NOT NULL COMMENT '个人所得税',
  `rent` decimal(8,2) NOT NULL COMMENT '房租',
  `deduct_add` decimal(8,2) NOT NULL COMMENT '应扣合计',
  `wages` decimal(8,2) NOT NULL COMMENT '实发工资',
  `year` varchar(7) NOT NULL,
  `time` char(11) NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hg_wageshg`
-- -----------------------------
DROP TABLE IF EXISTS `hg_wageshg`;
CREATE TABLE `hg_wageshg` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `num` int(10) NOT NULL COMMENT '序号',
  `section` varchar(8) NOT NULL COMMENT '部门名称',
  `name` varchar(16) NOT NULL COMMENT '用户姓名',
  `card` varchar(20) NOT NULL COMMENT '卡号',
  `job_wages` decimal(8,2) NOT NULL COMMENT '职务工资',
  `level_wages` decimal(8,2) NOT NULL COMMENT '级别工资',
  `job_subsidies` decimal(8,2) NOT NULL COMMENT '工作性补贴',
  `life_subsidies` decimal(8,2) NOT NULL COMMENT '生活性补贴',
  `haiguan_subsidies` decimal(8,2) NOT NULL COMMENT '海关补贴',
  `audit_subsidies` decimal(8,2) NOT NULL COMMENT '审计人员补贴',
  `secret_subsidies` decimal(8,2) NOT NULL COMMENT '机要保密津贴',
  `lifephone_subsidies` decimal(8,2) NOT NULL COMMENT '生活补贴、电话补贴',
  `phone_subsidies` decimal(8,2) NOT NULL COMMENT '移动通信补贴',
  `officialphone` decimal(8,2) NOT NULL COMMENT '公务电话费',
  `onechild` decimal(8,2) NOT NULL COMMENT '独生子女费',
  `giveadd` decimal(8,2) NOT NULL COMMENT '应发合计',
  `de_medicalinsurance` decimal(8,2) NOT NULL COMMENT '所得税扣除医疗保险',
  `de_gongjijing` decimal(8,2) NOT NULL COMMENT '所得税扣除公积金',
  `de_onechild` decimal(8,2) NOT NULL COMMENT '所得税扣除独生子女',
  `de_phone` decimal(8,2) NOT NULL COMMENT '所得税扣除移动电话及座机',
  `de_other` decimal(8,2) NOT NULL COMMENT '所得税扣除其他扣款',
  `de_taxadd` decimal(8,2) NOT NULL COMMENT '应缴税所得额',
  `individualtax` decimal(8,2) NOT NULL COMMENT '个人所得税',
  `rent` decimal(8,2) NOT NULL COMMENT '房租',
  `deduct_add` decimal(8,2) NOT NULL COMMENT '应扣合计',
  `wages` decimal(8,2) NOT NULL COMMENT '实发工资',
  `year` varchar(7) NOT NULL,
  `time` char(11) NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hg_wagesjsj`
-- -----------------------------
DROP TABLE IF EXISTS `hg_wagesjsj`;
CREATE TABLE `hg_wagesjsj` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `num` int(10) NOT NULL COMMENT '序号',
  `section` varchar(8) NOT NULL COMMENT '部门名称',
  `name` varchar(16) NOT NULL COMMENT '用户姓名',
  `card` varchar(20) NOT NULL COMMENT '卡号',
  `job_wages` decimal(8,2) NOT NULL COMMENT '职务工资',
  `level_wages` decimal(8,2) NOT NULL COMMENT '级别工资',
  `internship_wages` decimal(8,2) NOT NULL COMMENT '实习工资',
  `job_subsidies` decimal(8,2) NOT NULL COMMENT '工作性补贴',
  `life_subsidies` decimal(8,2) NOT NULL COMMENT '生活性补贴',
  `phone_subsidies` decimal(8,2) NOT NULL COMMENT '移动通信补贴',
  `officialphone` decimal(8,2) NOT NULL COMMENT '公务电话费',
  `bit_subsidies` decimal(8,2) NOT NULL COMMENT '警衔补贴',
  `onechild` decimal(8,2) NOT NULL COMMENT '独生子女费',
  `giveadd` decimal(8,2) NOT NULL COMMENT '应发合计',
  `de_medicalinsurance` decimal(8,2) NOT NULL COMMENT '应扣医疗保险',
  `de_gongjijing` decimal(8,2) NOT NULL COMMENT '应扣公积金',
  `de_base` decimal(8,2) NOT NULL COMMENT '扣税基数',
  `individualtax` decimal(8,2) NOT NULL COMMENT '应扣所得税',
  `rent` decimal(8,2) NOT NULL COMMENT '税后扣除项目：房租（按月）',
  `de_jobsubsidies` decimal(8,2) NOT NULL COMMENT '扣发工作性津贴',
  `deduct_add` decimal(8,2) NOT NULL COMMENT '应扣合计',
  `wages` decimal(8,2) NOT NULL COMMENT '实发工资',
  `year` varchar(7) NOT NULL,
  `time` char(11) NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hg_wagestx`
-- -----------------------------
DROP TABLE IF EXISTS `hg_wagestx`;
CREATE TABLE `hg_wagestx` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `num` int(10) NOT NULL COMMENT '序号',
  `section` varchar(8) NOT NULL COMMENT '部门名称',
  `name` varchar(16) NOT NULL COMMENT '用户姓名',
  `card` varchar(20) NOT NULL COMMENT '卡号',
  `retire_wages` decimal(8,2) NOT NULL COMMENT '离（退）休费',
  `retire_subsidies` decimal(8,2) NOT NULL COMMENT '离（退）休人员补贴',
  `officialphone` decimal(8,2) NOT NULL COMMENT '公务电话费',
  `lawpolice_subsidies` decimal(8,2) NOT NULL COMMENT '政法干警补贴',
  `nursing` decimal(8,2) NOT NULL COMMENT '护理费',
  `keep_subsidies` decimal(8,2) NOT NULL COMMENT '保留津贴',
  `wages` decimal(8,2) NOT NULL COMMENT '合计',
  `year` varchar(7) NOT NULL,
  `time` char(11) NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hg_zxadminbudgetmoney`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxadminbudgetmoney`;
CREATE TABLE `hg_zxadminbudgetmoney` (
  `overlook_id` int(8) NOT NULL,
  `name_id` int(8) NOT NULL,
  `inbudgetadd` varchar(8) DEFAULT NULL COMMENT '收入预算合计',
  `inlastadd` varchar(20) DEFAULT NULL COMMENT '上年结转小计',
  `intwolastadd` varchar(20) DEFAULT NULL COMMENT '上年，两年前结转',
  `inthisadd` varchar(20) DEFAULT NULL COMMENT '当年收入预算小计',
  `inthiserxia` varchar(20) DEFAULT NULL COMMENT '当年收入二下数',
  `inthistiaozheng` varchar(20) DEFAULT NULL COMMENT '收入调整数',
  `outbudgetadd` varchar(20) DEFAULT NULL COMMENT '支出预算合计',
  `outjiezhuanadd` varchar(20) DEFAULT NULL COMMENT '支出，结转支出小计',
  `outjiezhuantwolast` varchar(20) DEFAULT NULL COMMENT '支出，两年前形成结转',
  `outthisinoutbudget` varchar(20) DEFAULT NULL COMMENT '当年收入支出预算'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxadminbudgetmoney`
-- -----------------------------
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminbudgetmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_zxadminname`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxadminname`;
CREATE TABLE `hg_zxadminname` (
  `id` int(8) NOT NULL,
  `name` varchar(40) NOT NULL COMMENT '执行费用名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxadminname`
-- -----------------------------
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');
INSERT INTO `hg_zxadminname` VALUES ('', '');

-- -----------------------------
-- Table structure for `hg_zxadminoverlook`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxadminoverlook`;
CREATE TABLE `hg_zxadminoverlook` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `pid` int(8) NOT NULL COMMENT '父id',
  `year` int(5) NOT NULL COMMENT '年份',
  `month` int(3) DEFAULT NULL COMMENT '月份',
  `unitid` int(8) NOT NULL COMMENT '单位id',
  `time` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxadminoverlook`
-- -----------------------------
INSERT INTO `hg_zxadminoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxadminoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxadminoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxadminoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxadminoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxadminoverlook` VALUES ('', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_zxadminusemoney`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxadminusemoney`;
CREATE TABLE `hg_zxadminusemoney` (
  `overlook_id` int(8) NOT NULL,
  `name_id` int(8) NOT NULL,
  `inadd` varchar(8) DEFAULT NULL COMMENT '实际收入，合计',
  `inlast` varchar(20) DEFAULT NULL COMMENT '收入，调整上年结转',
  `inthisadd` varchar(20) DEFAULT NULL COMMENT '收入，当期实际收入',
  `outadd` varchar(20) DEFAULT NULL COMMENT '支出，合计',
  `outjzout` varchar(20) DEFAULT NULL COMMENT '支出，结转资金支出',
  `outthisout` varchar(20) DEFAULT NULL COMMENT '支出，当期收入支出'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxadminusemoney`
-- -----------------------------
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');
INSERT INTO `hg_zxadminusemoney` VALUES ('', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_zxqiye`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxqiye`;
CREATE TABLE `hg_zxqiye` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `year` int(5) NOT NULL,
  `month` int(3) NOT NULL,
  `unitid` int(8) NOT NULL,
  `sectionname` varchar(20) NOT NULL,
  `lastshishou` varchar(20) NOT NULL COMMENT '上年所有者权益，实收资本',
  `lastgongji` varchar(20) NOT NULL COMMENT '上年所有者权益，资本公积',
  `lastyingyu` varchar(20) NOT NULL COMMENT '上年所有者权益，盈余公积',
  `lastwei` varchar(20) NOT NULL COMMENT '上年所有者权益，未分配利润',
  `inzhuying` varchar(20) NOT NULL COMMENT '收入，主营收入',
  `inother` varchar(20) NOT NULL COMMENT '收入，其它业务收入',
  `outzhuying` varchar(20) NOT NULL COMMENT '支出，主营业务支出',
  `outother` varchar(20) NOT NULL COMMENT '支出，其它业务支出',
  `time` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxqiye`
-- -----------------------------
INSERT INTO `hg_zxqiye` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxqiye` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_zxshetuan`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxshetuan`;
CREATE TABLE `hg_zxshetuan` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `year` int(5) NOT NULL,
  `month` int(3) NOT NULL,
  `unitid` int(8) NOT NULL,
  `sectionname` varchar(20) NOT NULL,
  `lastadd` varchar(20) NOT NULL COMMENT '上年结余',
  `inhuifei` varchar(20) NOT NULL COMMENT '收入，会费收入',
  `inyewu` varchar(20) NOT NULL COMMENT '收入，业务收入',
  `outyewu` varchar(20) NOT NULL COMMENT '支出，业务支出',
  `outguanli` varchar(20) NOT NULL COMMENT '支出，管理支出',
  `time` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxshetuan`
-- -----------------------------
INSERT INTO `hg_zxshetuan` VALUES ('', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxshetuan` VALUES ('', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_zxshiye`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxshiye`;
CREATE TABLE `hg_zxshiye` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `year` int(5) NOT NULL,
  `month` int(3) NOT NULL,
  `unitid` int(8) NOT NULL,
  `sectionname` varchar(20) NOT NULL,
  `lastshiye` varchar(20) NOT NULL COMMENT '上年结余，事业基金',
  `lastzhuanyong` varchar(20) NOT NULL COMMENT '上年结余，专用基金',
  `inshiye` varchar(20) NOT NULL COMMENT '收入，事业收入',
  `injingying` varchar(20) NOT NULL COMMENT '收入，经营收入',
  `outshiye` varchar(20) NOT NULL COMMENT '支出，事业支出',
  `outjingying` varchar(20) NOT NULL COMMENT '支出，经营支出',
  `time` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxshiye`
-- -----------------------------
INSERT INTO `hg_zxshiye` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxshiye` VALUES ('', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_zxwuxiangmoney`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxwuxiangmoney`;
CREATE TABLE `hg_zxwuxiangmoney` (
  `overlook_id` int(8) NOT NULL,
  `name_id` int(8) NOT NULL,
  `alladd` varchar(8) DEFAULT NULL COMMENT '总合计',
  `jingfeiztadd` varchar(20) DEFAULT NULL COMMENT '经费账套合计',
  `czadd` varchar(20) DEFAULT NULL COMMENT '财政小计',
  `czyunxing` varchar(20) DEFAULT NULL COMMENT '财政，行政运行',
  `czjishi` varchar(20) DEFAULT NULL COMMENT '财政缉私办案',
  `czshoufei` varchar(20) DEFAULT NULL COMMENT '财政，收费业务',
  `czother` varchar(20) DEFAULT NULL COMMENT '财政，其它',
  `nczadd` varchar(20) DEFAULT NULL COMMENT '非财政，小计',
  `nczotherin` varchar(20) DEFAULT NULL COMMENT '非财政，其它收支',
  `nczdfzx` varchar(20) DEFAULT NULL COMMENT '非财政，地方专项',
  `dfztadd` varchar(20) DEFAULT NULL COMMENT '地方账套合计',
  `dfdf` varchar(20) DEFAULT NULL COMMENT '地方账套，地方',
  `dfzypay` varchar(20) DEFAULT NULL COMMENT '地方套帐，转移支付'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxwuxiangmoney`
-- -----------------------------
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangmoney` VALUES ('', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `hg_zxwuxiangname`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxwuxiangname`;
CREATE TABLE `hg_zxwuxiangname` (
  `id` int(8) NOT NULL,
  `name` varchar(40) NOT NULL COMMENT '执行费用名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxwuxiangname`
-- -----------------------------
INSERT INTO `hg_zxwuxiangname` VALUES ('', '');
INSERT INTO `hg_zxwuxiangname` VALUES ('', '');
INSERT INTO `hg_zxwuxiangname` VALUES ('', '');
INSERT INTO `hg_zxwuxiangname` VALUES ('', '');
INSERT INTO `hg_zxwuxiangname` VALUES ('', '');

-- -----------------------------
-- Table structure for `hg_zxwuxiangoverlook`
-- -----------------------------
DROP TABLE IF EXISTS `hg_zxwuxiangoverlook`;
CREATE TABLE `hg_zxwuxiangoverlook` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `pid` int(8) NOT NULL COMMENT '父id',
  `year` int(5) NOT NULL COMMENT '年份',
  `month` int(3) DEFAULT NULL COMMENT '月份',
  `unitid` int(8) NOT NULL COMMENT '单位id',
  `time` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hg_zxwuxiangoverlook`
-- -----------------------------
INSERT INTO `hg_zxwuxiangoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangoverlook` VALUES ('', '', '', '', '', '');
INSERT INTO `hg_zxwuxiangoverlook` VALUES ('', '', '', '', '', '');
